# Open Source Eurorack Synthesizer

Schematics and PCBs for my Eurorack modules

<img width="600" alt="Synth" src="https://github.com/Fihdi/Eurorack/assets/35708046/629cc893-058c-42b1-bda3-f0d630107174">

Each module has some minor or major bug, they are summarised in the "Known_Issues.txt" of each module.
